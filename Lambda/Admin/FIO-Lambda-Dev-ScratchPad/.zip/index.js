// FIO-Lambda-Dev-ScratchPad

'use strict';
const qlib = require("./QuantaLib/FIO-QuantaLib");
const _ = require("lodash");

exports.handler = (event, context, callback) => {

    let functionNames = [
        "Core-TransactionIngest",
        "HookHandler-Plaid",
        "HookHandler-AppleSubscription",
        "Nightly-System-Batch",
        "Nightly-System-Turndown",
        "Nightly-System-BatchMonitor",
        "Nightly-User-Items",
        "Nightly-User-FlowNotify",
        "Nightly-User-PickItem",
        "Nightly-User-Quantize",
        "Nightly-User-Item-PlaidPull",
        "Nightly-User-Item-PlaidPullStatusCheck",
        "Nightly-Analytics",
        "ASDS-User-Subscription-ReceiptValidate",
        "ASDS-User-Delete",
        "ASDS-User-AuthExists",
        "ASDS-Item-Delete",
        "ASDS-Item-Create",
        "ASDS-Item-Status",
        "ASDS-Item-FreshToken",
        "ASDS-User-Transactions-Search",
        "ASDS-User-Transactions",
        "ASDS-User-Notifs-Device-Update"
    ];

    let prefix = "QIO-Lambda-";

    qlib.lambda.createFunction(prefix + _.first(functionNames));
};
