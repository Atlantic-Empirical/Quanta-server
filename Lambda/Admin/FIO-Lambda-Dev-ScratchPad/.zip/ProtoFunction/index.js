'use strict';
//
//  QIO-Lambda-
//
//  Created by Thomas Purnell-Fisher
//  Copyright © 2018-2019 Flow Capital, LLC. All rights reserved.
//
//  Description: 
//  Input:
//  Output: 
//

const qlib = require("./QuantaLib/FIO-QuantaLib");
const _ = require("lodash");

exports.handler = (event, context, callback) => {
    console.log(context.functionName + '() EVENT =\n' + JSON.stringify(event));

};
