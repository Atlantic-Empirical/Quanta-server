// FIO-Notify

'use strict';
const AWS = require('aws-sdk');
const _ = require('lodash');
const _async = require('async');

const q_ddb = require("../AWS/FIO-AWS-DDb");
const q_sns = require("../AWS/FIO-AWS-SNS");

module.exports = {

    notifyUser: (userId, title, body, callback, badgeCount = 0, sound = 'default', collapseKey = 1) =>
        _notifyUser(userId, title, body, callback, badgeCount = 0, sound = 'default', collapseKey = 1),

};

function _notifyUser(userId, title, body, callback, badgeCount = 0, sound = 'default', collapseKey = 1) {
    _async.auto({
        pull_erns: cb => {
            q_ddb.query('NP-Push-Device-Tokens', ['userId', 'tokenPlatform'], [userId, 0], cb, undefined, 'endpointArn, tokenPlatform', 0, 'SPECIFIC_ATTRIBUTES');
        },
        format_bodies: ['pull_erns', (results, cb) => {
            _.each(results.pull_erns, ern => {
                let s = _.split(ern.endpointArn, "/");
                let isProd = s[1] == "APNS";
                ern.payload = buildApnPayload(title, body, badgeCount, sound, collapseKey, isProd);
                ern.messageStructure = 'json';
            });
            cb(null, results.pull_erns);
        }],
        dispatch_messages: ['format_bodies', (results, cb) => {
            var publishResults = [];
            _async.each(results.format_bodies,
                (item, cb_each) => {
                    q_sns.publish(item,
                        (err, data) => {
                            if (err) console.log(err.message);
                            else publishResults.push(data);
                            cb_each();
                        }
                    );
                },
                err => cb(err, publishResults)
            );
        }]
    }, callback);
}

function buildApnPayload(title, body, badgeCount, sound, collapseKey, forProd, customData = {}) {
    if (!forProd) body += " [SANDBOX]";
    var messageBodyObjJSON = JSON.stringify({
        aps: {
            alert: {
                title: title,
                body: body
            },
            sound: sound,
            badge: badgeCount,
        },
        customData: customData
    });
    let payload = forProd ? { APNS: messageBodyObjJSON } : { APNS_SANDBOX: messageBodyObjJSON };
    let payloadStr = JSON.stringify(payload);
    console.log("Final payload JSON: " + payloadStr);
    return payloadStr;
}
