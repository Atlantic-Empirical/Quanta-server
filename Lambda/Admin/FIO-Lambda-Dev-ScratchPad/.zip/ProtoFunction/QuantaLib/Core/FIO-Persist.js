// FIO-Persist

'use strict';
const AWS = require('aws-sdk');
const ddb = new AWS.DynamoDB();
const _ = require('lodash');
const _async = require('async');
require('../Helper/cycle.js');

// const moment = require("moment");
const appRoot = process.cwd();
const moment = require(appRoot + "/ThirdParty/moment/moment-timezone-with-data-2012-2022");

const q_ddb = require('../AWS/FIO-AWS-DDb');
const q_date = require("../Util/FIO-Util-Date");
const q_log = require('./FIO-Logging');

module.exports = {

    // ITEM
    pullItem: (item_id, callback, projections) => q_ddb.getItem('FIO-Table-Items', 'item_id', item_id, callback, projections),
    pullItemByLinkSessionId: (link_session_id, callback, projections) =>
        q_ddb.query('FIO-Table-Items', 'link_session_id', link_session_id, callback, 'link_session_id-index', projections, 1),
    removeItem: (item_id, callback) => q_ddb.deleteItem('FIO-Table-Items', 'item_id', item_id, callback),
    persistItem: (item, callback) => q_ddb.putItem('FIO-Table-Items', item, callback),
    pullItemAccounts: (item_id, callback, projection) =>
        q_ddb.query('FIO-Table-Accounts', 'item_id', item_id, callback, 'item_id-index', projection),
    persistItemAccounts: (accounts, callback) => q_ddb.batchWrite('FIO-Table-Accounts', accounts, callback),
    pullItemTransactions: (item_id, callback, projection) =>
        q_ddb.query('FAC-Transactions', 'item_id', item_id, callback, 'item_id-index', projection),
    pullItemUserId: (item_id, callback) => q_ddb.getItem('FIO-Table-Items', 'item_id', item_id, callback, undefined, 'userId'),
    pullItemWebhooks: (item_id, callback, projections) =>
        q_ddb.query('FAC-Webhooks', 'item_id', item_id, callback, 'item_id-index', projections),
    pullItemHistoricalWebhookCount: (item_id, callback) => _pullItemHistoricalWebhookCount(item_id, callback),
    setItemLastTransactionPullToNow: (item_id, callback) => _setItemLastTransactionPullToNow(item_id, callback),
    setItemNeedsUpdateFlag: (item_id) => _setItemNeedsUpdateFlag(item_id),
    pullLastTransactionRetrievalTimestamp: (item_id, callback) => _pullLastTransactionRetrievalTimestamp(item_id, callback),
    institutionNameForId: (item_id, callback) =>
        q_ddb.getItem('FIO-Table-Items', 'item_id', item_id, callback, undefined, 'institution_name'),
    incrementItemBatchCount: (item_id) => _incrementItemBatchCount(item_id),
    decrementItemBatchCount: (item_id) => _decrementItemBatchCount(item_id),
    setItemBatchCountToZero: (item_id) => _setItemBatchCountToZero(item_id),
    persistItemBatchArn: (item_id, batchArn, callback) =>
        q_ddb.update('FIO-Table-Items', 'item_id', item_id, 'set', 'batchArn', batchArn, callback),
    oldestTransactionDateForItem: (item_id, callback) => _oldestTransactionDateForItem(item_id, callback),
    transactionCountForItem: (item_id, callback) => _transactionCountForItem(item_id, callback),

    // USER - Transactions
    pullUserTransactions: (userId, transaction_ids, includeAccount, callback, projections) =>
        _pullUserTransactions(userId, transaction_ids, includeAccount, callback, projections),
    pullAllUserTransactions: (userId, callback) => _pullAllUserTransactions(userId, null, [], callback),
    persistUserTransactionCategory: (userId, transaction, callback) => _persistUserTransactionCategory(userId, transaction, callback),
    batchDeleteTransactions: (transactions, callback) =>
        q_ddb.batchDelete('FAC-Transactions', transactions, 'userId', 'transaction_id', callback),
    batchDeleteTransactionsByTids: (userId, tids, callback) => _batchDeleteTransactionsByTids(userId, tids, callback),
    batchWriteTransactions: (transactions, callback) => q_ddb.batchWrite('FAC-Transactions', transactions, callback),

    // USER - Items
    pullUserItems: (userId, callback) => q_ddb.query('FIO-Table-Items', 'userId', userId, callback, 'userId-index'),

    // USER - Details
    persistUserDetailObject: (userId, type, object, callback) => _persistUserDetailObject(userId, type, object, callback),
    pullUserDetailObjects: (userId, callback, projection) =>
        q_ddb.query('FIO-Table-User-Details', 'userId', userId, callback, 'userId-index', projection),
    persistUserFlow: (userId, thatFlow, callback) => _persistUserFlow(userId, thatFlow, callback),
    pullUserFlow: (userId, callback) => q_ddb.query('FIO-Table-User-Flow', 'userId', userId, callback, 'userId-to-periodId-index'),
    batchDeleteDetailObjs: (detailObjs, callback) => q_ddb.batchDelete('FIO-Table-User-Details', detailObjs, 'userId', 'objectTypeId', callback),
    batchDeleteUserFlow: (flowObjs, callback) => q_ddb.batchDelete('FIO-Table-User-Flow', flowObjs, 'userId', 'periodId', callback),

    // USER - Push Devices / Notif Related
    pullUserPushDevices: (userId, callback) => q_ddb.query('NP-Push-Device-Tokens', 'userId', userId, callback, 'userId-index'),
    batchDeletePushDevices: (devices, callback) => q_ddb.batchDelete('NP-Push-Device-Tokens', devices, 'tokenPlatform', 'userId', callback),
    storePlatformEndpoint: (userId, deviceToken, endpointArn, callback) => _storePlatformEndpoint(userId, deviceToken, endpointArn, callback),
    pullUserDeviceToken: (userId, callback) => q_ddb.query('NP-Push-Device-Tokens', ['userId', 'tokenPlatform'], [userId, 0], callback),

    // USER - Other
    pullUserSubscriptionReceipt: (userId, callback) => _pullUserSubscriptionReceipt(userId, callback),
    pullUserAccounts: (userId, callback) => _pullUserAccounts(userId, callback),
    pullUserSub: (userId, callback) => _pullUserSub(userId, callback),
    removeUserFromUserMapTable: (userId, callback) => q_ddb.deleteItem('FIO-Table-UserMap', 'userId', userId, callback),
    pullUserIdForSub: (sub, callback) => _pullUserIdForSub(sub, callback),

    // ACCOUNTS
    persistAccountFreshBalances: (account, callback) => _persistAccountFreshBalances(account, callback),
    persistAccount: (account, callback) => _persistAccount(account, callback),
    removeAccount: (masterAccountId, callback) => q_ddb.deleteItem('FIO-Table-Accounts', 'masterAccountId', masterAccountId, callback),

    // OTHER
    batchDeleteWebhooks: (hooks, callback) => q_ddb.batchDelete('FAC-Webhooks', hooks, 'item_id', 'timestamp', callback),

    // SYSTEM
    pullAllPendingTransactions: callback => _pullAllPendingTransactions(callback),
    pendingTransactionSweep: callback => _pendingTransactionSweep(callback),

};

// NOTIFS

function _storePlatformEndpoint(userId, deviceToken, endpointArn, callback) {
    q_ddb.putItem('NP-Push-Device-Tokens', {
        userId: userId,
        tokenPlatform: 0,
        tokenValue: deviceToken,
        endpointArn: endpointArn
    }, callback);
}

// TRANSACTIONS

function _pendingTransactionSweep(callback) {
    _async.auto({
            set_table_throughput: cb => q_ddb.comprehensiveSetTableThroughput('FAC-Transactions', false, 50, 0, 'minval', cb),
            pull_pending_transactions: cb => module.exports.pullAllPendingTransactions(cb),
            pull_matching_non_pending_transactions: ['pull_pending_transactions', (results, cb) => {
                var ptids = _.map(results.pull_pending_transactions, 'transaction_id');
                pullMatchingNonPendingTransactions(ptids, cb);
            }],
            delete_pending_transactions_with_matched_non_pending: ['pull_matching_non_pending_transactions', (results, cb) => {
                let collatedForBatchDelete = _
                    .chain(results.pull_matching_non_pending_transactions)
                    .filter(TX => !_.isNil(TX.userId) && !_.isNil(TX.pending_transaction_id))
                    .map(TX => ({ transaction_id: TX.pending_transaction_id, userId: TX.userId }))
                    .value();
                module.exports.batchDeleteTransactions(collatedForBatchDelete, cb);
            }],
            log_counts: ['pull_pending_transactions', 'pull_matching_non_pending_transactions', (results, cb) => {
                q_log.interesting({
                    totalPendingTransactionsBeforeCull: results.pull_pending_transactions.length,
                    matchedNonPendingTransactions: results.pull_matching_non_pending_transactions.length,
                    totalPendingTransactionsAfterCull: results.pull_pending_transactions.length - results.pull_matching_non_pending_transactions.length
                }, "_pendingTransactionSweep");
                cb();
            }],
        },
        (err, results) => {
            if (err) console.log('ERROR in _pendingTransactionSweep: ' + err);
            callback(err, results);
        }
    );
}

function _pullAllPendingTransactions(callback) {
    q_ddb.scan('FAC-Transactions', (err, res) => {
        if (err) callback(err);
        else {
            _.each(res, tx => delete tx.location);
            // let csv = json2csv(res);
            // console.log('\n' + csv);
            callback(null, res);
        }
    }, 'pending', true);

    // let params = {
    //     TableName: ,
    //     ExpressionAttributeValues: { ":true": AWS.DynamoDB.Converter.input(true) },
    //     FilterExpression: "pending = :true"
    // };
}

function pullMatchingNonPendingTransactions(tids, callback) {
    console.log("in pull_matching_non_pending_transactions");
    // query for each one of the pending transactions' id in other transactions' pending_transaction_id field

    let chunks = _.chunk(tids, 100);
    let out = [];

    _async.each(chunks, (chunk, cb_each) => {

            var expressionAttributeValuesObject = {};
            _.each(tids, (ptid, i) =>
                expressionAttributeValuesObject[":ptid" + i] = AWS.DynamoDB.Converter.input(ptid));

            var params = {
                TableName: "FAC-Transactions",
                FilterExpression: "#ptid IN (" + Object.keys(expressionAttributeValuesObject).toString() + ")",
                ExpressionAttributeValues: expressionAttributeValuesObject,
                ExpressionAttributeNames: { '#ptid': 'pending_transaction_id' }
            };

            q_ddb.scanWithParams(params, (err, res) => {
                if (err) cb_each(err);
                else {
                    _.each(res, tx => delete tx.location);
                    out.push(...res);
                    cb_each();
                }
            });
        },
        err => {
            if (err) callback(err);
            else callback(null, out);
        }
    );
}

function _batchDeleteTransactionsByTids(userId, tids, callback) {
    let objs = _.map(tids, tid => ({ transaction_id: tid, userId: userId }));
    q_ddb.batchDelete('FAC-Transactions', objs, 'userId', 'transaction_id', callback);
}

function _pullUserTransactions(userId, transaction_ids, includeAccount, callback, projections = "") {
    if (_.isUndefined(userId)) { callback("User context is required."); return; }
    if (_.isUndefined(transaction_ids) || _.isEmpty(transaction_ids)) { callback("Transactions req'd"); return; }

    if (!_.isArray(transaction_ids)) transaction_ids = [transaction_ids];
    let keys = _
        .chain(transaction_ids)
        .compact()
        .filter(tid => !_.isEmpty(tid))
        .map(tid => ({
            userId: userId,
            transaction_id: tid
        }))
        .value();

    q_ddb.batchGet('FAC-Transactions', keys, 'userId', (err, res) => {
        if (includeAccount) addAccountDetailsToTransactions(res, callback);
        else callback(err, res);
    }, projections, 'transaction_id');
}

function _pullAllUserTransactions(userId, LastEvaluatedKey, transactionArray, callback) {

    performTransactionQuery(userId, LastEvaluatedKey, (err, transactions, LastEvaluatedKey) => {
        if (err) callback(err);
        else {
            transactionArray = _.concat(transactionArray, transactions);

            if (LastEvaluatedKey) {
                console.log('Looks like we have more transactions to pull.');
                _pullAllUserTransactions(userId, LastEvaluatedKey, transactionArray, callback);
            }
            else {
                console.log('Done pulling. Returning ' + transactionArray.length + ' transactions back up the chain.');
                callback(null, transactionArray);
            }
        }
    });
}

function performTransactionQuery(userId, LastEvaluatedKey, callback) {

    var params = {
        TableName: process.env.TABLE_TRANSACTIONS || 'FAC-Transactions',
        IndexName: 'userId-index',
        ExpressionAttributeValues: { ":v1": AWS.DynamoDB.Converter.input(userId) },
        KeyConditionExpression: "userId = :v1"
    };

    if (!_.isNull(LastEvaluatedKey)) {
        params.ExclusiveStartKey = LastEvaluatedKey;
    }

    ddb.query(params, (err, data) => {
        if (err) {
            console.log('ERROR in performTransactionQuery: ' + err);
            callback(err);
        }
        else {
            console.log("Loop pull count: " + data.Items.length);
            // console.log("pullAllTransactionsForUser ddb.query response d: " + JSON.stringify(d));
            let outTransactions = _.map(_.get(data, 'Items'), AWS.DynamoDB.Converter.unmarshall);
            callback(null, outTransactions, data.LastEvaluatedKey);
        }
    });
}

function addAccountDetailsToTransactions(transactions, callback) {

    if (_.isEmpty(transactions)) {
        callback(null, transactions);
        return;
    }

    let uniqueMasterAccountIds = _
        .chain(transactions)
        .map('masterAccountId')
        .uniq().value();

    var accounts = [];

    _async.each(uniqueMasterAccountIds,

        (masterAccountId, cb_each) => {
            q_ddb.getItem('FIO-Table-Accounts', 'masterAccountId', masterAccountId, (err, res) => {
                if (err) cb_each(err);
                else {
                    accounts.push(res);
                    cb_each();
                }
            }, undefined, 'institution_name, masterAccountId, name');
        },

        (err) => {
            if (err) callback(err);
            else {
                // that's the end - all the loops have returned.

                _.each(transactions, tx => {
                    let matchedAccount = _.find(accounts, ai => ai.masterAccountId == tx.masterAccountId);
                    // console.log('lookup: ' + JSON.stringify(matchedAccount));
                    tx.account_name = matchedAccount.name;
                    tx.account_institution_name = matchedAccount.institution_name;
                });

                callback(null, transactions);
            }
        }
    );
}

function _persistUserTransactionCategory(userId, transaction, callback) {

    let params = {
        TableName: "FAC-Transactions",
        ExpressionAttributeValues: { ":c": AWS.DynamoDB.Converter.input(transaction.fioCategoryId) },
        Key: {
            "userId": AWS.DynamoDB.Converter.input(userId),
            "transaction_id": AWS.DynamoDB.Converter.input(transaction.transaction_id)
        },
        UpdateExpression: "SET fioCategoryId = :c"
    };
    // console.log(JSON.stringify(params, null, 2));

    ddb.updateItem(params, function(err, data) {

        if (err) {
            // console.log(err, 'Failed to batch write in putTransactionsIntoDdb():\n' + err.message + ' Stack:\n' + err.stack);

            if (err.code == "ProvisionedThroughputExceededException") {
                console.log('ProvisionedThroughputExceededException. Going to increase throughput.');

                // Increase write throughput
                // this should use ddb.waitForState()
                q_ddb.comprehensiveSetTableThroughput('FAC-Transactions', true, 100, 100, 'minval', (err, result) => {
                    if (err) console.log(err);
                    _persistUserTransactionCategory(userId, transaction, callback); // retry WITHOUT backoff
                });
            }
            else {
                console.log('unhandled write error: ' + err);
                callback(err, 'bailed out due to write error: ' + err);
            }
        }
        else {
            // console.log(JSON.stringify(data));
            // console.log('transaction updated: ' + transaction.transaction_id);
            callback(err, data);
        }
    });
}

// USER DETAILS

function _persistUserDetailObject(userId, type, object, callback) {
    // console.log('persistDetailObject() type: ' + type + ' object: ' + JSON.stringify(object, null, 2));

    if (_.isUndefined(object)) {
        // Item is orphaned, delete any remanant.

        let deleteParams = {
            TableName: process.env.TABLE_USER_DETAILS || 'FIO-Table-User-Details',
            Key: {
                "userId": AWS.DynamoDB.Converter.input(userId),
                "objectTypeId": AWS.DynamoDB.Converter.input(type)
            }
        };

        ddb.deleteItem(deleteParams, (err, data) => {
            if (err) console.log('persistDetailObject FAILURE to delete orphaned item: ' + err.message);
            // else { console.log('ddb.query response data: ' + JSON.stringify(data)) }
            callback(err);
        });
    }
    else {

        object.objectTypeId = type;
        object.userId = userId;
        object.createdTimestamp = Date.now();

        let params = {
            TableName: process.env.TABLE_DETAILS || 'FIO-Table-User-Details',
            Item: AWS.DynamoDB.Converter.marshall(object)
        };
        // console.log(JSON.stringify(params, null, 2));

        ddb.putItem(params, (err, data) => {
            if (err) {
                console.log('ERROR: _persistDetailObject (put) (type ' + type + '): ' + err);
                let decycled = JSON.decycle(object);
                console.log("\nNAUGHTY OBJECT =\n" + JSON.stringify(decycled, null, 2));
            }
            callback(err);
        });
    }
}

function _persistUserFlow(userId, thatFlow, callback) {

    let objs = _.map(thatFlow, I => {
        I.userId = userId;
        I.createdTimestamp = Date.now();
        return I;
    });

    q_ddb.batchWrite('FIO-Table-User-Flow', objs, callback);
}

// SUBSCRIPTIONS

function _pullUserSubscriptionReceipt(userId, callback) {

    let params = {
        TableName: process.env.TABLE_DETAILS || 'FIO-Table-User-Details',
        ExpressionAttributeValues: {
            ":v1": AWS.DynamoDB.Converter.input(userId),
            ":v2": AWS.DynamoDB.Converter.input(6)
        },
        KeyConditionExpression: "userId = :v1 AND objectTypeId = :v2",
        ProjectionExpression: "latest_receipt_b64"
    };

    ddb.query(params, function(err, d) {
        if (err) callback(err);
        else {
            let objs = _.map(d.Items, I => AWS.DynamoDB.Converter.unmarshall(I));
            let first = _.first(objs);
            if (_.isUndefined(first)) callback('No existing subscription object for user.');
            else if (_.isUndefined(first.latest_receipt_b64)) callback('No latest receipt string.');
            else callback(null, first.latest_receipt_b64);
        }
    });
}

// USER

function _pullUserSub(userId, callback) {
    q_ddb.getItem('FIO-Table-UserMap', 'userId', userId, (err, res) => {
        if (err) callback(err);
        else callback(null, _.get(res, 'sub'));
    }, 'sub');
}

function _pullUserIdForSub(sub, callback) {
    q_ddb.query('FIO-Table-UserMap', 'sub', sub, (err, res) => {
        if (err) callback(err);
        else callback(null, _.get(res, 'userId'));
    }, "sub-index", 'userId', 1);
}

// ACCOUNTS

function _pullUserAccounts(userId, callback) {

    let params = {
        TableName: process.env.TABLE_ACCOUNTS || 'FIO-Table-Accounts',
        IndexName: 'userId-index',
        KeyConditionExpression: "userId = :v1",
        ExpressionAttributeValues: { ":v1": AWS.DynamoDB.Converter.input(userId) }
    };

    ddb.query(params, (err, data) => {
        if (err) {
            console.log('ERROR in _pullUserAccounts: ' + err);
            callback(err);
        }
        else {
            // console.log('ddb.query response data: ' + JSON.stringify(data));
            let accounts = _.map(_.get(data, 'Items'), AWS.DynamoDB.Converter.unmarshall);
            // console.log(JSON.stringify(accounts, null, 2));
            callback(null, accounts);
        }
    });
}

function _persistAccountFreshBalances(account, callback) {
    q_ddb.update('FIO-Table-Accounts', 'masterAccountId', account.masterAccountId, 'set', ['balances', 'lastSynced'], [account.balances, Date.now()], (err, res) => {
        if (err) {
            console.log('ERROR: _persistAccountFreshBalances: ' + err);
            let decycled = JSON.decycle(account);
            console.log("\nNAUGHTY OBJECT =\n" + JSON.stringify(decycled, null, 2));
        }
        callback(err);
    });
}

function _persistAccount(account, callback) {

    let params = {
        TableName: process.env.TABLE_ACCOUNTS || 'FIO-Table-Accounts',
        Item: AWS.DynamoDB.Converter.marshall(account)
    };
    // console.log(JSON.stringify(params, null, 2));

    ddb.putItem(params, (err, data) => {
        if (err) {
            console.log('ERROR: _persistNewAccount (put): ' + err);
            let decycled = JSON.decycle(account);
            console.log("\nNAUGHTY OBJECT =\n" + JSON.stringify(decycled, null, 2));
        }
        callback(err);
    });
}

// ITEMS

function _pullItemHistoricalWebhookCount(item_id, callback) {
    q_ddb.query('FAC-Webhooks', 'item_id', item_id, callback, 'item_id-index', undefined, 0, 'COUNT', 'webhook_code', 'HISTORICAL_UPDATE');
}

function _pullLastTransactionRetrievalTimestamp(item_id, callback) {
    const sinceLastTransactionPullDaysToExtendBack = 20;
    q_ddb.getItem('FIO-Table-Items', 'item_id', item_id, (err, item) => {
        if (err) {
            console.log('ERROR in _pullLastTransactionRetrievalTimestamp: ' + err);
            callback(err);
        }
        else {
            if (_.isUndefined(item) || _.isUndefined(item.lastTransactionPull) || item.lastTransactionPull == 0) {
                console.log('Last transaction pull is NEVER -- setting to ten years ago');
                callback(null, q_date.tenYearsAgoString());
            }
            else {
                let lastTransactionPullM = moment(item.lastTransactionPull);
                let todayM = moment();
                console.log('last transaction pull was at: ' + lastTransactionPullM.format('dddd, MMMM Do YYYY, h:mm:ss a'));

                // check to ensure that we're not setting start date to today
                if (lastTransactionPullM.isSameOrAfter(todayM, 'day')) {
                    lastTransactionPullM = todayM.subtract(sinceLastTransactionPullDaysToExtendBack, 'day'); // set to N days ago to ensure that no transactions are missed.
                    console.log('setting transaction pull start date to: ' + lastTransactionPullM.format('YYYY-MM-DD'));
                }
                callback(null, lastTransactionPullM.format('YYYY-MM-DD'));
            }
        }
    }, undefined, 'lastTransactionPull');
}

function _setItemLastTransactionPullToNow(item_id, callback) {
    q_ddb.update('FIO-Table-Items', 'item_id', item_id, 'set', 'lastTransactionPull', Date.now(), (err, res) => {
        if (err) console.log('ERROR in _setItemLastTransactionPullToNow: ' + err);
        else console.log('_setItemLastTransactionPullToNow succeeded');
        callback(err);
    });
}

function _setItemNeedsUpdateFlag(item_id) {
    q_ddb.update('FIO-Table-Items', 'item_id', item_id, 'set', 'needsUpdate', true, (err, res) => {
        if (err) console.log('failed to setItemNeedsUpdateFlag: ' + err);
        else console.log('setItemNeedsUpdateFlag succeeded');
    });
}

function _incrementItemBatchCount(item_id) {
    if (_.isNil(item_id) || _.isEmpty(item_id)) { console.log('_decrementItemBatchCount() Item context is required.'); return; }

    q_ddb.update('FIO-Table-Items', 'item_id', item_id, 'add', 'transactionPullBatchCount', -1, (err, res) => {
        if (err) console.log('failed to increment batch count: ' + err);
        else console.log('batch count incremented.');
    });
}

function _decrementItemBatchCount(item_id) {
    if (_.isNil(item_id) || _.isEmpty(item_id)) { console.log('_decrementItemBatchCount() Item context is required.'); return; }

    q_ddb.update('FIO-Table-Items', 'item_id', item_id, 'add', 'transactionPullBatchCount', -1, (err, res) => {
        if (err) console.log('ERROR in _decrementItemBatchCount for item: ' + item_id + "\n" + err);
        else {
            console.log('batch count decremented for item: ' + item_id);
            if (res.transactionPullBatchCount < 0) {
                console.log('This put the batch count below zero (' + res.transactionPullBatchCount + '). Going to set it back to zero.'); // hack
                _setItemBatchCountToZero(item_id);
            }
        }
    }, undefined, undefined, 'UPDATED_NEW');
}

function _setItemBatchCountToZero(item_id) {
    q_ddb.update('FIO-Table-Items', 'item_id', item_id, 'set', 'transactionPullBatchCount', 0, (err, res) => {
        if (err) console.log("ERROR in _setItemBatchCountToZero: " + err);
    });
}

function _transactionCountForItem(item_id, callback) {
    q_ddb.query('FAC-Transactions', 'item_id', item_id, (err, res) => {
        if (err) {
            console.log('Error in ddb.query: ' + err, err.stack);
            callback(err);
        }
        else {
            // console.log('ddb.query response data: ' + JSON.stringify(data));
            callback(null, res.Count);
        }
    }, 'item_id-index', undefined, 0, "COUNT");
}

function _oldestTransactionDateForItem(item_id, callback) {
    q_ddb.query('FAC-Transactions', 'item_id', item_id, (err, res) => {
        if (err) callback(err);
        else {
            // console.log('ddb.query response data: ' + JSON.stringify(data));
            let out = _.chain(res).map('date').sort().first().value();
            callback(null, out);
        }
    }, 'item_id-index', 'date');
}

// SCRAP

// function pullSingleUserTransaction(userId, transaction_id, includeAccount, callback) {
//     let projection = includeAccount ? "account_id" : undefined;

//     q_ddb.getItem('FAC-Transactions', ['userId', 'transaction_id'], [userId, transaction_id], (err, res) => {
//         if (err) callback(err);
//         else {
//             if (_.isUndefined(res) || _.isEmpty(res)) {
//                 callback();
//             }
//             else if (includeAccount) {

//                 addAccountDetailsToTransactions([res], (err, res) => {
//                     if (err) callback(err);
//                     else {
//                         let out = _.map(res, tx => q_obj.compactObject(tx));
//                         callback(null, out);
//                     }
//                 });
//             }
//             else
//                 callback(null, q_obj.compactObject(res));
//         }
//     }, undefined, projection);
// }
