// FIO-Logging

'use strict';
const AWS = require('aws-sdk');
const cwl = new AWS.CloudWatchLogs();
const _ = require('lodash');

const groupName_SignificantErrors = 'FIO-Log-Group-Errors-Significant';
const groupName_InvestigateFurther = 'FIO-Log-Group-InvestigateFurther';
const groupName_Interesting = 'FIO-Log-Group-Interesting';

module.exports = {

    interesting: (messageObj, functionName) => _putLogEventWithSequenceToken(messageObj, groupName_Interesting, functionName),
    investigateFurther: (messageObj, functionName) => _putLogEventWithSequenceToken(messageObj, groupName_InvestigateFurther, functionName),
    significantError: (messageObj, functionName) => _putLogEventWithSequenceToken(messageObj, groupName_SignificantErrors, functionName),
    genericPutLogEvent: (messageObj, groupName, streamName) => _putLogEventWithSequenceToken(messageObj, groupName, streamName),

};

function _putLogEventWithSequenceToken(messageObj, groupName, streamName, sequenceToken) {
    console.log('putLogEventWithSequenceToken()');
    console.log('groupName = ' + groupName);
    console.log('streamName = ' + streamName);

    let preppedMessage = JSON.stringify(messageObj, null, 2);
    console.log('MESSAGE:\n' + preppedMessage);

    let params = {
        logGroupName: groupName,
        logStreamName: streamName,
        logEvents: [{
            message: preppedMessage,
            timestamp: Date.now()
        }]
    };

    if (!_.isUndefined(sequenceToken) && !_.isEmpty(sequenceToken))
        params.sequenceToken = sequenceToken;

    // console.log(JSON.stringify(params, null, 2));

    cwl.putLogEvents(params, (err, res) => {

        if (err) {
            console.log('ERROR in putLogEvents: ' + JSON.stringify(err, null, 2));

            if (err.code == 'ResourceNotFoundException' && err.message == 'The specified log group does not exist.') {
                _createLogGroup(groupName, (err, res) => {
                    if (err) console.log(err);
                    else _putLogEventWithSequenceToken(messageObj, groupName, streamName);
                });
            }
            else if (err.code == 'ResourceNotFoundException' && err.message == 'The specified log stream does not exist.') {
                _createLogStream(groupName, streamName, (err, res) => {
                    if (err) console.log(err);
                    else _putLogEventWithSequenceToken(messageObj, groupName, streamName);
                });
            }
            else if (err.code == 'DataAlreadyAcceptedException') {
                _getSequenceToken(groupName, streamName, (err, newSequenceToken) => {
                    if (err) console.log(err);
                    else _putLogEventWithSequenceToken(messageObj, groupName, streamName, newSequenceToken);
                });
            }
            else if (err.code == 'InvalidSequenceTokenException') {
                // "The given sequenceToken is invalid. The next expected sequenceToken is: 49590642936978815254013931168165128425698134452890372338"
                let newSequenceToken = _.chain(err.message).split(":").last().trim().value() || '';
                console.log('newSequenceToken = ' + newSequenceToken);
                _putLogEventWithSequenceToken(messageObj, groupName, streamName, newSequenceToken);
            }
        }
    });
}

function _createLogGroup(groupName, callback) { cwl.createLogGroup({ logGroupName: groupName, }, callback) }

function _createLogStream(groupName, streamName, callback) {
    console.log('Creating log stream: ' + streamName);

    cwl.createLogStream({
        logGroupName: groupName,
        logStreamName: streamName
    }, callback);
}

function _getSequenceToken(logGroupName, streamName, callback) {
    console.log('Getting sequence token.');

    let params = {
        logGroupName: logGroupName,
        limit: 1,
        logStreamNamePrefix: streamName,
    };

    cwl.describeLogStreams(params, (err, data) => {
        if (err) callback(err);
        else {
            let stream = _.first(data.logStreams);
            let sequenceToken = _.get(stream, 'uploadSequenceToken');
            console.log('sequenceToken = ' + sequenceToken);
            callback(null, sequenceToken);
        }
    });
}
