// FIO-AWS-Cognito

'use strict';
const AWS = require('aws-sdk');
const cogId = new AWS.CognitoIdentity();
const cognitoISP = new AWS.CognitoIdentityServiceProvider();
const _ = require('lodash');

const userPoolId = 'us-east-1_qEX0vG1or';

module.exports = {

    deleteFederatedIdentityForUser: (userId, callback) => cogId.deleteIdentities({ IdentityIdsToDelete: [userId] }, callback),
    deleteCognitoIdentityForUserSub: (sub, callback) => _deleteCognitoIdentityForUserSub(sub, callback),
    listUsers: (attributeName, attributeValue, callback) => _listUsers(attributeName, attributeValue, callback),

};

function _deleteCognitoIdentityForUserSub(sub, callback) {
    if (_.isUndefined(sub)) callback(null, 'No sub/username passed in.');
    else {
        cognitoISP.adminDeleteUser({
                UserPoolId: userPoolId,
                Username: sub
            },
            (err, data) => {
                if (err) {
                    if (err.code == "UserNotFoundException") {
                        console.log('User not found in Cognito. Continuing.');
                        callback();
                    }
                    else {
                        console.log('ERROR in _deleteCognitoIdentityForUserSub: ' + err);
                        callback(err);
                    }
                }
                else callback();
            }
        );
    }
}

function _listUsers(attributeName, attributeValue, callback) {

    cognitoISP.listUsers({
            UserPoolId: userPoolId,
            Filter: attributeName + ' ^= \"' + attributeValue + '\"'
        },
        (err, data) => {
            if (err) callback(err);
            else {

                // Makes everything lowercase, but not remembering why...
                let out = _.map(data.Users, U => {
                    var user = {
                        username: U.Username,
                        createDate: U.UserCreateDate,
                        lastModifiedDate: U.UserLastModifiedDate,
                        enabled: U.Enabled,
                        userStatus: U.UserStatus,
                        attributes: {}
                    };
                    _.each(U.Attributes, A => user.attributes[A.Name] = A.Value);
                    return user;
                });

                callback(null, out);
            }
        }
    );
}
