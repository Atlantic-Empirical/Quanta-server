// FIO-AWS-Lambda

'use strict';
const AWS = require('aws-sdk');
const lambda = new AWS.Lambda();
const _ = require("lodash");

module.exports = {

    invoke: (name, callback, payload, invokeType) => _invoke(name, callback, payload, invokeType),
    createFunction: (name, memory, timeout, description) => _createFunction(name, memory, timeout, description),

};

function _createFunction(name, memory = 128, timeout = 30, description = "") {
    lambda.createFunction({
        Code: {
            S3Bucket: 'app.flow.quantalib',
            S3Key: 'ProtoFunction.zip',
        },
        Description: description,
        FunctionName: name,
        Handler: "index.handler",
        MemorySize: memory,
        Publish: true,
        Role: "arn:aws:iam::475512417340:role/Role-Chedda-Lambda",
        Runtime: "nodejs8.10",
        Timeout: timeout
    }, (err, data) => {
        if (err) console.log(err, err.stack);
        else console.log(data);
    });
}

function _invoke(name, callback, payload, invokeType = 'Event') {
    var params = {
        FunctionName: name,
        InvocationType: invokeType
    };
    if (!_.isNil(payload))
        params.Payload = JSON.stringify(payload);
    // console.log('lambda invoke params =\n' + JSON.stringify(params, null, 2));
    lambda.invoke(params,
        (err, data) => {
            if (err) callback(err);
            else if (data) {
                if (data.StatusCode == 202 && invokeType == "Event") callback(); // Not waiting for response.
                else {
                    let payload = JSON.parse(data.Payload);
                    console.log('lambda.invoke response for ' + name + '\nPayload: ' + JSON.stringify(payload, null, 2));
                    if (payload.errorMessage) callback(payload.errorMessage); // happens on timeout of lambda and other things
                    callback(null, payload);
                }
            }
            else callback(); // Nothing was returned
        }
    );
}
