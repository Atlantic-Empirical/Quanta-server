// FIO-Util-Date

'use strict';
const _ = require('lodash');
const appRoot = process.cwd();
const Moment = require(appRoot + "/ThirdParty/moment/moment-timezone-with-data-2012-2022");
const MomentRange = require(appRoot + "/ThirdParty/moment-range/moment-range");
const moment = MomentRange.extendMoment(Moment);
const q_math = require('./FIO-Util-Math');

var hasBeenInit = false;

module.exports = {

    moment: _theMoment(), // expose our special moment
    dateIsBetween: (inspectDate, startDate, endDate) => _dateIsBetween(inspectDate, startDate, endDate),
    daysAgoForDate: dateStringOrMoment => _daysAgoForDate(dateStringOrMoment),
    closestDateInArray: (momentArray, inspectDateStrOrM, toleranceDays) => _closestDateInArray(momentArray, inspectDateStrOrM, toleranceDays),
    dateDistributionForDateSet: dateStrings => _dateDistributionForDateSet(dateStrings),
    tenYearsAgoString: () => moment().subtract(10, 'years').format("YYYY-MM-DD"),

};

function _theMoment() {
    if (!hasBeenInit) init();
    return moment;
}

function _dateIsBetween(inspectDate, startDate, endDate) {
    if (!hasBeenInit) init();
    let start = moment(startDate, 'YYYY-MM-DD');
    let end = moment(endDate, 'YYYY-MM-DD').add(1, 'days');
    let inspectDateM = moment(inspectDate, 'YYYY-MM-DD');
    let res = moment().range(start, end).contains(inspectDateM);
    // console.log('dateIsBetween(' + inspectDate + ') ' + startDate + ' -- ' + endDate + ' = ' + res);
    return res;
}

function _dateDistributionForDateSet(dateStrings) {
    if (!hasBeenInit) init();
    // console.log('Analyze date distribution of:\n' + JSON.stringify(dateStrings, null, 2));
    var diffDays = [];
    _.each(dateStrings, (dateString, index, collection) => {
        let m1 = moment(dateString);
        if (index + 1 < collection.length) {
            let d2String = collection[index + 1];
            let d = m1.diff(d2String, 'days');
            // console.log(dateString + ' - ' + d2String + ' diff days: ' + d.toString());
            diffDays.push(d);
        }
    });
    // EXCLUDE 0 CASES (WHEN THERE WERE TWO TRANSACTIONS ON SAME DAY)
    diffDays = _.filter(diffDays, diff => diff != 0);
    let avgDiffDays = _.round(_.mean(diffDays), 2);
    // console.log('avgerage days: ' + avgDiffDays);
    let standardDeviation = q_math.stdDev(diffDays) || 0;
    // console.log('stdDev: ' + standardDeviation);
    let relativeStandardDeviationPct = q_math.relativeStandardDeviation(standardDeviation, avgDiffDays); //_.round((100 * standardDeviation) / avgDiffDays, 2) || 0;
    // console.log('relativeStandardDeviation: ' + relativeStandardDeviation);
    let out = {
        avgDiffDays: avgDiffDays,
        standardDeviation: standardDeviation,
        relativeStandardDeviationPct: relativeStandardDeviationPct,
        firstDate: _.last(dateStrings),
        lastDate: _.first(dateStrings),
    };
    let projectedNextDateM = moment(out.lastDate).add(out.avgDiffDays, 'days');
    out.daysUntilNext = Math.abs(moment().diff(projectedNextDateM, 'days'));
    // ADD DAYS-AGO
    out.lastDaysAgo = _daysAgoForDate(out.lastDate);
    out.firstDaysAgo = _daysAgoForDate(out.firstDate);
    out.duration = out.firstDaysAgo - out.lastDaysAgo;
    // console.log('Date Distribution Summary:\n' + JSON.stringify(out, null, 2));
    return out;
}

function _daysAgoForDate(dateStringOrMoment) {
    if (!hasBeenInit) init();
    return moment().diff(moment(dateStringOrMoment), 'days');
}

function _closestDateInArray(momentArray, inspectDateStrOrM, toleranceDays) {
    if (!hasBeenInit) init();
    let out = _
        .chain(momentArray)
        .each(m => m.diff = Math.abs(moment(inspectDateStrOrM).diff(m)))
        .orderBy('diff', 'asc')
        .first()
        .value();

    if (moment.duration(out.diff).asDays() > toleranceDays) return; // Nearest date is outside the tolerance.
    else return out;
}

function init() {
    console.log("*** Moment Initialize ***");
    moment.updateLocale('en', { week: { dow: 1 } }); // Set first day of week to monday
    moment.tz.setDefault("America/New_York"); // set timezone to eastern
    hasBeenInit = true;
}
