// FIO-Analysis-Income

'use strict';
const _ = require('lodash');
// const moment = require('moment');
const appRoot = process.cwd();
const moment = require(appRoot + "/ThirdParty/moment/moment-timezone-with-data-2012-2022");
const qlib = require('../QuantaLib/FIO-QuantaLib');

module.exports = {

    incomeForDate: (dateString, userIncome) => _incomeForDate(dateString, userIncome)

};

function _incomeForDate(dateString, userIncome) {
    if (_.isNil(userIncome)) return 0;
    return _
        .chain(userIncome)
        .thru(v => _.concat(v.activeStreams, v.otherStreams))
        .filter(incomeStream => {
            let daysToExtendStreams = incomeStream.dateDistribution.avgDiffDays;
            daysToExtendStreams += (incomeStream.periodSize == 'biweekly' ? 5 : 10);
            let adjustedEndDateM = moment(incomeStream.dateDistribution.lastDate).add(daysToExtendStreams, 'days'); // add the grace period
            return qlib.date.dateIsBetween(dateString, incomeStream.dateDistribution.firstDate, adjustedEndDateM.format('YYYY-MM-DD'));
        })
        .map('amountDistribution.dailyEstimate')
        .reduce((m, i) => m + i)
        .value() || 0;
}
