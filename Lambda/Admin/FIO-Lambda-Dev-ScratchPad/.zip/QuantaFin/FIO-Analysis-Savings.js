// FIO-Analysis-Savings

'use strict';
const AWS = require('aws-sdk');
const _ = require('lodash');
// const moment = require('moment');
const appRoot = process.cwd();
const moment = require(appRoot + "/ThirdParty/moment/moment-timezone-with-data-2012-2022");

const DAYS_IN_YEAR = 365.2422;
const AVG_DAYS_PER_MONTH = DAYS_IN_YEAR / 12;
const monthsToAnalyzeForDetailObjects = 12;
const daysToAnalyzeForDetailObjects = _.round(AVG_DAYS_PER_MONTH * monthsToAnalyzeForDetailObjects, 0);

module.exports = {

    buildSavingsDetail: (accounts, userHome, months) =>
        _buildSavingsDetail(accounts, userHome, months)

};

function _buildSavingsDetail(accounts, userHome, months) {

    let savingsAccounts = _.filter(accounts, A => A.subtype == 'savings');

    if (_.isEmpty(savingsAccounts))
        return; // User has no savings accounts

    var out = {
        daysAnalyzed: daysToAnalyzeForDetailObjects,
        accounts: savingsAccounts,
        dates: [],
        months: []
    };

    var cursorM = moment().subtract(1, 'day');

    _.times(daysToAnalyzeForDetailObjects,
        idx => {

            let v = {
                date: cursorM.format('YYYY-MM-DD'),
                balance: 0
            };

            _.each(savingsAccounts,
                A => {
                    let dayObj = _.find(A.statementDays, O => O.date == v.date);
                    v.balance += _.get(dayObj, 'endingBalance', 0);
                }
            );

            out.dates.push(v);
            cursorM.subtract(1, 'day');
        }
    );

    // Now go by months to build the data model for the "over time" graphs in the savings detail view

    _.each(months,
        month => {
            let monthStr = moment(month.startDate).format('YYYY-MM');
            let balances = _.get(month, 'periodSummary.balances');
            var monthSavingsBalanceDelta = 0;
            var bufferAtStartOfMonth = 0;

            // Calculate realized savings rate if there are balances
            if (!_.isUndefined(balances)) {

                let overallEndingBalance = _
                    .chain(balances)
                    .filter(I => I.accountSubtype == 'savings')
                    .map('endingBalance')
                    .reduce((m, i) => m + i)
                    .round(2)
                    .value() || 0;
                console.log('overallEndingBalance = ' + overallEndingBalance);

                let overallStartingBalance = _
                    .chain(balances)
                    .filter(I => I.accountSubtype == 'savings')
                    .map('startingBalance')
                    .reduce((m, i) => m + i)
                    .round(2)
                    .value() || 0;
                console.log('overallStartingBalance = ' + overallStartingBalance);

                monthSavingsBalanceDelta = overallEndingBalance - overallStartingBalance;
                if (_.isNaN(monthSavingsBalanceDelta)) // guarding against the unknown here.
                    monthSavingsBalanceDelta = 0;

                let avgSpendThreePriorMonths = monthlySpendAvgForPriorMonths(userHome.spendingSummary, 3, monthStr) || 0;
                if (avgSpendThreePriorMonths > 0)
                    bufferAtStartOfMonth = _.round(overallStartingBalance / avgSpendThreePriorMonths, 1);

            }

            // "potential" reflects the amount you came out ahead for the month but not
            // whether you actually put the surplus into savings/investments.

            out.months.push({
                month: monthStr,
                savingsRate_potential: month.periodSummary.income == 0 ? 0 : _.round(Math.max(month.periodSummary.netAmount, 0) / month.periodSummary.income, 2),
                savingsRate_realized: month.periodSummary.income == 0 ? 0 : _.round(monthSavingsBalanceDelta / month.periodSummary.income, 2), // realized numerator = deposits to savings and transfers to investment accounts
                bufferAtStartOfMonth: bufferAtStartOfMonth
            });
        }
    );

    out.avgBalance = _.chain(out.dates).map('balance').mean().round(2).value();
    out.currentTotalBalance = _.head(out.dates).balance;
    out.avgSavingsRate_realized = _.chain(out.months).map('savingsRate_realized').mean().round(4).value();
    out.avgSavingsRate_potential = _.chain(out.months).map('savingsRate_potential').mean().round(4).value();

    // console.log('Savings Detail:\n' + JSON.stringify(out, null, 2));

    return out;
}

function monthlySpendAvgForPriorMonths(spendingSummary, monthCount, fromMonthStr) {

    var out = 0;

    let sortedMonths = _
        .chain(spendingSummary.months)
        .orderBy('month', 'desc')
        .tail() // don't include the current partial month.
        .dropRight(1) // don't include the oldest month which is also partial.
        .value();

    _.each(sortedMonths,

        (M, idx) => {

            if (M.month == fromMonthStr) {

                out = _
                    .chain(spendingSummary.months)
                    .slice(idx, idx + monthCount)
                    .map('amount')
                    .mean()
                    .round(2)
                    .value();

                return false; // Break loop
            }
        }
    );

    console.log('monthlySpendAvgForPriorMonths = ' + out);
    return out;
}
