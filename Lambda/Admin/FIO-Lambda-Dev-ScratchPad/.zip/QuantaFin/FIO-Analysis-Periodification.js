// FIO-Analysis-Periodification

'use strict';
const _ = require('lodash');
// const moment = require('moment');
const appRoot = process.cwd();
const moment = require(appRoot + "/ThirdParty/moment/moment-timezone-with-data-2012-2022");
const q_income = require('./FIO-Analysis-Income');
const qlib = require('../QuantaLib/FIO-QuantaLib');
const q_cats = require('./FIO-Transaction-Categorize');

module.exports = {

    buildFlowPeriodsForWindowSize: (windowSize, dateNets, statementDays, userIncomeForProjection, categoriesForProjection) =>
        buildFlowPeriodsForWindowSize_inner(windowSize, dateNets, statementDays, userIncomeForProjection, categoriesForProjection)

};

function buildFlowPeriodsForWindowSize_inner(windowSize, dateNets, statementDays, userIncomeForProjection, categoriesForProjection) {

    setupMoment();

    // BATCH IT UP!
    let userFlow = batchDatesToWindowSize(windowSize, dateNets, statementDays);

    // ADD CATEGORIES
    _.each(userFlow, function(period) {
        addCategoriesToPeriod(period);
    });

    // ADD PROJECTION (IF NEEDED)
    if (windowSize == 7 || windowSize == 30) {

        // START DATE
        let oldestDateNet = _.last(dateNets);
        let startDateStr = oldestDateNet.date;
        let startDateM = moment(startDateStr);

        // Guard to ensure that the start date is the beginning of a week/month when appropriate
        if (windowSize == 7) {
            startDateM.startOf('week');
        }
        else if (windowSize == 30) {
            startDateM.startOf('month');
        }

        // END DATE
        let endDateStr = _.first(userFlow).endDate;

        if (moment().isBetween(startDateM, endDateStr, 'day', '[]')) {

            console.log('Projection is needed. Building and adding it now.');

            let currentPeriod = _.find(userFlow, function(p) {
                return moment().isBetween(p.startDate, p.endDate, 'day', '[]');
            });

            // console.log('currentPeriod:\n' + JSON.stringify(currentPeriod, null, 2));

            addProjectionToPeriod(currentPeriod, userIncomeForProjection, categoriesForProjection);
        }
    }

    // DONE!!
    return userFlow;
}

// PERIOD BUILD - BATCHING

function batchDatesToWindowSize(windowSize, dateNets, statementDays) {

    // This is where the magic happens 🧙🔮

    var out;

    if (windowSize == 1)
        out = _.map(dateNets, DN => conformDateObject(DN, statementDays));

    else if (windowSize == 7)
        out = batchForWeeks(dateNets, statementDays);

    else if (windowSize == 30)
        out = batchForMonths(dateNets, statementDays);

    else {
        console.error('Invalid windowSize.');
        return [];
    }

    let oldestDateNet = _.last(dateNets);
    tagFinalPeriod(out, oldestDateNet.date);

    return out;
}

function conformDateObject(date, statementDays) {

    let out = {
        periodId: date.date,
        windowSize: 1,
        startDate: date.date,
        endDate: date.date,
        daysInRange: 1,
        daysRemainingInPeriod: 0,
        periodSummary: {
            netAmount: date.netAmount || 0,
            income: date.income || 0,
            transactions: date.transactions,
            balances: balancesForDate(date.date, statementDays)
        }
    };

    addSpendingSummary(out);

    return out;
}

function batchForWeeks(dateNets, statementDays) {

    let cursorM = moment().subtract(1, 'day');
    var allWeeks = [];
    var thisWeek = [];

    _.each(dateNets, function(dateNet) {
        // console.log(cursorM.format('YYYY-MM-DD'));
        // console.log(cursorM.weekday());

        thisWeek.push(dateNet);

        if (cursorM.weekday() == 0) {

            // This is monday, stash the weeks and start fresh
            allWeeks.push(thisWeek);
            thisWeek = [];

        }

        cursorM.subtract(1, 'day');
    });

    // Push any tailing days as there usually will be (~6/7 of the time) some previous days in thisWeek when the loop hits the end.
    allWeeks.push(thisWeek);

    return _.map(allWeeks, function(datesForWeek) {

        return batchDaysIntoTemplate(datesForWeek, 7, statementDays);

    });
}

function batchForMonths(dateNets, statementDays) {

    let monthPeriods = [];

    let oldestDateNet = _.last(dateNets);
    let numberOfMonths = moment().diff(oldestDateNet.date, 'months') + 2; // Make it inclusive, not sure exactly why it has to be 2
    let cursorM = moment();
    console.log(oldestDateNet.date);

    _.times(numberOfMonths, function(idx) {

        let cursorMonthPrefix = cursorM.format('YYYY-MM');

        let dateNetsForMonth = _.filter(dateNets, function(dateNet) {
            return dateNet.date.startsWith(cursorMonthPrefix);
        });

        if (_.isEmpty(dateNetsForMonth)) {
            let isOldestMonth = (cursorMonthPrefix == moment(oldestDateNet.date).format(("YYYY-MM")));
            console.log("No dateNets for month: " + cursorMonthPrefix + " isLastMonth = " + isOldestMonth);
            console.log("If false, something is very wrong. If true, it is the result of the +2 above.");
        }
        else {
            monthPeriods.push(batchDaysIntoTemplate(dateNetsForMonth, 30, statementDays));
        }

        cursorM.subtract(1, 'month');
    });

    return monthPeriods;
}

// dateObjectArray MUST be passed in aligned to week/month boundaries.
function batchDaysIntoTemplate(dateObjectArray, windowSize, accountDays) {
    // console.log('batchDaysIntoTemplate');

    var weekOrMonth;

    if (windowSize == 7) {
        weekOrMonth = 'week';
    }
    else if (windowSize == 30) {
        weekOrMonth = 'month';
    }
    else {
        return 'Invalid windowSize';
    }

    // Sanity check date alignment.
    var startDateStr = _.last(dateObjectArray).date;
    let startDateM = moment(startDateStr).startOf(weekOrMonth); // only changes val for the very first week/month
    startDateStr = startDateM.format('YYYY-MM-DD');

    let endDateM = moment(startDateM).endOf(weekOrMonth); // this is needed for the current week, if yesterday isn't the end of a week/month, this moves it over to align with one.
    let endDateStr = endDateM.format('YYYY-MM-DD');

    let daysRemainingInPeriod = endDateM.diff(moment(), 'days') + 1;
    let daysInRange = endDateM.diff(moment(startDateM), 'days') + 1;

    // Build balances
    var endDateForBalancesStr;

    if (daysRemainingInPeriod >= 0) {
        // End date is in the future or is today, use yesterday for balances
        endDateForBalancesStr = moment().subtract(1, 'day').format('YYYY-MM-DD');
    }
    else {
        endDateForBalancesStr = endDateStr;
    }

    let bals = balancesForPeriod(startDateStr, endDateForBalancesStr, accountDays);

    // Calc periodId
    var periodId;

    if (weekOrMonth == 'week') {

        // https://momentjs.com/docs/#/displaying/format/
        periodId = startDateM.format('gggg-[W]ww'); // the brackets escape the W (for 'week')

    }
    else if (weekOrMonth == 'month') {
        periodId = startDateM.format('YYYY-MM');

    }

    let out = {
        periodId: periodId,
        windowSize: windowSize,
        startDate: startDateStr,
        endDate: endDateStr,
        daysInRange: daysInRange,
        daysRemainingInPeriod: daysRemainingInPeriod,
        periodSummary: {
            netAmount: qlib.obj.mapReduce(dateObjectArray, "netAmount"),
            income: qlib.obj.mapReduce(dateObjectArray, "income"),
            transactions: {
                totalAmount: qlib.obj.mapReduce(dateObjectArray, "transactions.totalAmount"),
                deposits: {
                    totalAmount: qlib.obj.mapReduce(dateObjectArray, "transactions.deposits.totalAmount") || 0,
                    transactionIds: qlib.obj.mapUnique(dateObjectArray, "transactions.deposits.transactionIds")
                },
                debits: {
                    totalAmount: qlib.obj.mapReduce(dateObjectArray, "transactions.debits.totalAmount") || 0,
                    transactionIds: qlib.obj.mapUnique(dateObjectArray, "transactions.debits.transactionIds"),
                    transactions: _.chain(dateObjectArray).map("transactions.debits.transactions").compact().flatten().value(),
                },
                transfers: {
                    totalAmount: qlib.obj.mapReduce(dateObjectArray, "transactions.transfers.totalAmount") || 0,
                    transactionIds: qlib.obj.mapUnique(dateObjectArray, "transactions.transfers.transactionIds")
                },
                regularIncome: {
                    totalAmount: qlib.obj.mapReduce(dateObjectArray, "transactions.regularIncome.totalAmount") || 0,
                    transactionIds: qlib.obj.mapUnique(dateObjectArray, "transactions.regularIncome.transactionIds")
                }
            },
            balances: bals
            // :)
            // 🐾🦁
        },
        dayNets: _.map(dateObjectArray, "netAmount")
    };

    addSpendingSummary(out);

    return out;
}

function addSpendingSummary(periodObject) {

    periodObject.periodSummary.spending = {
        actual: _.get(periodObject, 'periodSummary.transactions.debits.totalAmount', 0),
        target: -1,
        projected: 0 // added in addProjectionToPeriod_Inner()
    };
}

function firstDayOfPeriodObject(weekOrMonth) {
    console.log('firstDayOfPeriodObject()');

    var startDateM = moment().startOf(weekOrMonth);
    var endDateM = moment().endOf(weekOrMonth);
    var periodLength = endDateM.diff(startDateM, 'days') + 1;

    let out = {
        startDate: startDateM.format('YYYY-MM-DD'),
        endDate: endDateM.format('YYYY-MM-DD'),
        daysInRange: periodLength,
        daysRemainingInPeriod: endDateM.diff(moment(), 'days') + 1,
        periodSummary: {
            netAmount: 0,
            income: 0
            // transactions: {} // absent is ok
        },
        dayNets: Array(periodLength).fill(-1),
        includesEndOfData: false
    };

    addSpendingSummary(out);

    return out;
}

function tagFinalPeriod(obj, endOfDataDateStr) {

    _.each(obj, function(w) { w.includesEndOfData = false; }); // makes some client ops faster;

    // find the item in obj array where start-end == final date
    // OR start - end contains end date (inclusive)
    // set endOfDataDate and includesEndOfData in that object

    var d = _.find(obj, function(p) {
        if (endOfDataDateStr == p.startDate) { return true; }
        return moment(endOfDataDateStr).isAfter(moment(p.startDate).subtract(1, 'day'), 'day');
    });

    if (!_.isUndefined(d)) {
        d.includesEndOfData = true;
        d.endOfDataDate = endOfDataDateStr;
    }

    // trim off any entire empty periods that END prior to the endOfDataDate
    obj = _.filter(obj, function(d) { return moment(endOfDataDateStr).isBefore(d.endDate); });
}

// PERIOD BUILD - BALANCES

function balancesForDate(dateStr, statementDays) {

    // Gather account days just for the target date
    var statementDaysForDate = _.filter(statementDays, function(statementDay) { return statementDay.date == dateStr });
    if (_.isEmpty(statementDaysForDate)) {
        return null;
    }
    // console.log(JSON.stringify(statementDaysForDate, null, 2));

    // Now group the account days by account subtype
    let grouped = _.groupBy(statementDaysForDate, 'accountSubtype');

    // Now merge the arrays of account days within each group
    var merged = {};

    _.forOwn(grouped, function(value, key, obj) {

        merged[key] = {
            'startingBalance': _
                .chain(value)
                .map('startingBalance')
                .reduce((m, i) => m + i)
                .round(2)
                .value(),

            'endingBalance': _
                .chain(value)
                .map('endingBalance')
                .reduce((m, i) => m + i)
                .round(2)
                .value()
        };
    });

    // Now turn merged into a simple array instead of a map
    let out = _.transform(merged,

        function(result, value, key) {

            let obj = {
                accountSubtype: key
            };

            _.forOwn(value, function(value, key) {
                obj[key] = value;
            });

            result.push(obj);

        }, []);
    // console.log(JSON.stringify(out, null, 2));

    return out;
}

function balancesForPeriod(startDateStr, endDateStr, accountDays) {
    // console.log('balancesForPeriod() startDateStr: ' + startDateStr + ' endDateStr: ' + endDateStr);

    let startDayBalances = balancesForDate(startDateStr, accountDays);
    // console.log("startDayBalances:\n" + JSON.stringify(startDayBalances, null, 2));

    var endDayBalances = balancesForDate(endDateStr, accountDays);
    if (_.isNull(endDayBalances)) {
        endDateStr = moment(endDateStr).subtract(1, 'day').format('YYYY-MM-DD'); // try going back one further day
        endDayBalances = balancesForDate(endDateStr, accountDays);
    }
    if (_.isNull(endDayBalances)) {
        return []; // bail
    }
    // console.log("startDayBalances:\n" + JSON.stringify(endDayBalances, null, 2));

    _.each(startDayBalances, function(o, key) {

        let e = _.find(endDayBalances, { 'accountSubtype': o.accountSubtype });

        if (!_.isUndefined(e)) {
            o.endingBalance = e.endingBalance;
        }
    });

    // console.log(JSON.stringify(startDayBalances, null, 2));

    return startDayBalances;
}

// PERIOD BUILD - CATEGORIES

function addCategoriesToPeriod(period) {

    var cats = _.fill(Array(10), 0);
    var tids = new Array(10);
    tids = _.map(tids, function(itm) { return new Array(0) });

    let debitTransactionFragments = _.get(period, "periodSummary.transactions.debits.transactions", []);

    if (_.isEmpty(debitTransactionFragments)) return;

    _.each(debitTransactionFragments, function(txFragment) {

        let idx = q_cats.fioCatToIndex(txFragment.fioCategoryId);

        cats[idx] += txFragment.amount;
        tids[idx].push(txFragment.transaction_id);
    });

    period.periodSummary.categories = new q_cats.FIOSpendCategories(cats, tids);
}

// PERIOD BUILD - PROJECTION

function addProjectionToPeriod(period, userIncome, overallCategoriesFromUserHome) {
    // console.log('buildProjectionForPeriod()');
    // console.log(JSON.stringify(categorySummary, null, 2));

    let startM = moment(period.startDate);
    // console.log(startM.format('YYYY-MM-DD'));

    // INCOME
    // how much do they make each day of this period? Add them up.
    // note that the logic below *WILL* include future income from a recognized stream.

    let perDateIncomeForPeriod = [];

    // Add cut off dates to income
    _.each(userIncome.streams, function(stream) {
        stream.dateDistribution.cutoffDate = moment(stream.dateDistribution.lastDate).add(userIncome.consts.daysToExtendStreams, 'days').format('YYYY-MM-DD');
    });

    // Pull income for each date
    _.times(period.daysInRange, function(idx) {
        // console.log(startM.format('YYYY-MM-DD'));

        perDateIncomeForPeriod.push(
            q_income.incomeForDate(startM.format('YYYY-MM-DD'), userIncome)
        );

        startM.add(1, 'days'); // step forward a day
    });

    // console.log(JSON.stringify(perDateIncomeForPeriod));
    let totalRecognizedIncomeForPeriod = _.reduce(perDateIncomeForPeriod, function(m, i) { return m + i });
    // console.log(totalRecognizedIncomeForPeriod);

    let dailySpend = qlib.obj.financial(overallCategoriesFromUserHome.total / overallCategoriesFromUserHome.lookbackDayCount);
    console.log('dailySpend = ' + dailySpend);

    let realizedSpend = 0;
    if (!_.isUndefined(period.periodSummary) && !_.isUndefined(period.periodSummary.transactions) && !_.isUndefined(period.periodSummary.transactions.debits) && !_.isUndefined(period.periodSummary.transactions.debits.totalAmount)) {
        realizedSpend += period.periodSummary.transactions.debits.totalAmount;
    }
    realizedSpend = qlib.obj.financial(realizedSpend);
    // console.log('realizedSpend = ' + realizedSpend);

    let remainingSpend = qlib.obj.financial(-1 * (period.daysRemainingInPeriod * dailySpend));
    // console.log('leftToSpend = ' + remainingSpend);

    let projectedPeriodSpend = qlib.obj.financial(remainingSpend + realizedSpend); // spend is negative

    if (_.isUndefined(period.periodSummary.spending)) { addSpendingSummary(period) }
    period.periodSummary.spending.projected = projectedPeriodSpend;

    // NET
    let projectedPeriodNet = qlib.obj.financial(totalRecognizedIncomeForPeriod + projectedPeriodSpend);

    // SUMMARIZE
    console.log("");
    console.log("=====  PROJECTION  =====");
    console.log("");
    console.log('  remainingDays in period = ' + period.daysRemainingInPeriod);
    console.log('  estimated dailySpend = ' + dailySpend);
    console.log("");
    console.log('  realizedSpend = ' + realizedSpend);
    console.log('  remainingSpend = ' + remainingSpend);
    console.log("");
    console.log('  totalRecognizedIncomeForPeriod = ' + totalRecognizedIncomeForPeriod);
    console.log('  projectedSpendTotal = ' + projectedPeriodSpend);
    console.log('  projectedPeriodNet = ' + projectedPeriodNet);
    console.log("");
    console.log("=====");
    console.log("");

    period.projection = {
        incomeTotal: totalRecognizedIncomeForPeriod,
        spendTotal: projectedPeriodSpend,
        net: projectedPeriodNet
    };
}

function setupMoment() {
    moment.tz.setDefault("America/New_York"); // set timezone to eastern
    moment.updateLocale('en', { week: { dow: 1 } }); // Set first day of week to monday
}
