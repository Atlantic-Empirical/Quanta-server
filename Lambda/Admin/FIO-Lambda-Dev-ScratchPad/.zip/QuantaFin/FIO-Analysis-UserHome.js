// FIO-Analysis-UserHome

'use strict';
const AWS = require('aws-sdk');
const _ = require('lodash');
// const _async = require('async');
// const moment = require('moment');
const appRoot = process.cwd();
const moment = require(appRoot + "/ThirdParty/moment/moment-timezone-with-data-2012-2022");
const qlib = require('../QuantaLib/FIO-QuantaLib');
const q_creditUtilization = require('./FIO-Analysis-CreditUtilization');
const q_cats = require("./FIO-Transaction-Categorize");

const spendingSummaryMonthsToAnalyze = 12;
const DAYS_IN_YEAR = 365.2422;
const AVG_DAYS_PER_MONTH = DAYS_IN_YEAR / 12;

module.exports = {

    buildUserHome: (userId, accounts, categorySummary, income, items, transactions) =>
        _buildUserHome(userId, accounts, categorySummary, income, items, transactions)

};

function _buildUserHome(userId, accounts, categorySummary, income, items, transactions) {

    let spendingSummary = buildSpendingSummary(transactions);
    let dailyMoney = buildDailyMoney(income, spendingSummary);
    let savingsStatus = buildSavingsStatus(accounts, spendingSummary);

    let userHome = {

        userId: userId,
        flowScore: computeFlowScore(),
        safetyNet: savingsStatus,
        creditCards: q_creditUtilization.buildCreditCardSummary(accounts),
        accounts: accounts,
        items: items,
        dailyMoney: dailyMoney,
        overview: buildOverview(transactions),
        categories: new q_cats.FIOSpendCategories(categorySummary.amounts, categorySummary.tids),
        spendingSummary: spendingSummary,
        builtAtTicks: (new Date()).getTime()

    };

    // console.log('USER HOME\n' + JSON.stringify(userHome, null, 2));
    return userHome;
}

function buildSpendingSummary(transactions) {
    console.log('buildSpendingSummary()');

    let startDateM = moment().subtract(spendingSummaryMonthsToAnalyze, 'months');

    // this is expected to return an array of 13 becacuse there are days in month at either end
    var monthTotals = _
        .chain(transactions)
        .filter(tx => tx.isSpend && !(moment(tx.date).isBefore(startDateM))) // shouldn't transactionIsRecognizedTransferOrRefund() be used to determine isSpend?
        .each(tx => tx.amount = Math.abs(tx.amount)) // to get us on the same coordinate system (Credit vs. Debit)
        .groupBy(tx => tx.date.substring(0, 7))
        .map((monthTransactionArray, key) => {
            return {
                amount: qlib.obj.mapReduceFinancial(monthTransactionArray, 'amount'),
                month: key
            };
        })
        .orderBy('month', 'asc')
        .value();

    let threeMonthDailyAvg = _
        .chain(transactions)
        .filter(tx => tx.isSpend)
        .orderBy('date', 'desc')
        .take(91)
        .map('amount')
        .mean()
        .round(2)
        .value();

    let out = {
        total: qlib.obj.mapReduceFinancial(monthTotals, 'amount'),
        months: monthTotals,
        monthsAnalyzed: spendingSummaryMonthsToAnalyze,
        threeMonthDailyAvg: threeMonthDailyAvg
    };

    return out;
}

function buildSavingsStatus(accounts, spendingSummary) {

    var out = new SafetyNetStatus();

    // get just savings & money market accounts
    var savingsAccounts = _.filter(accounts, function(acct) {

        if (_.isUndefined(acct)) { return false }
        if (_.isObject(acct) && _.isEmpty(acct)) { return false }

        if (acct.subtype.toLowerCase() === "savings") { return true }
        if (acct.subtype.toLowerCase() === "money market") { return true }

        return false;
    });

    out.totalBalance = qlib.obj.mapReduceFinancial(savingsAccounts, 'balances.available');
    out.accountCount = savingsAccounts.length;

    let spendPerMonth = spendingSummary.threeMonthDailyAvg * AVG_DAYS_PER_MONTH;
    out.months = _.round(out.totalBalance / spendPerMonth, 2);
    out.percentageOfTargetMonths = _.round((out.months / out.targetMonths) * 100, 2);

    return out;
}

function computeFlowScore(userId) {
    return new FlowScore(userId);
}

function buildDailyMoney(userIncome, spendingSummary) {

    return {
        income: _.get(userIncome, 'activeDailyEstimate', 0),
        spend: _.get(spendingSummary, 'threeMonthDailyAvg', 0)
    };
}

function buildOverview(transactions, callback) {

    // Collect transactions
    // Filter down to checking account transactions only
    let filteredTransactions = _.filter(transactions, tx => tx.account.subtype == 'checking');
    let deposits = _.filter(filteredTransactions, tx => tx.amount > 0);
    let debits = _.filter(filteredTransactions, tx => tx.amount < 0);

    let out = {
        transactionCount: transactions.length,
        oldestTransactionDate: _.chain(transactions).orderBy('date', 'asc').first().value().date || '',
        totalIn: qlib.obj.mapReduceFinancial(deposits, 'amount'),
        totalOut: qlib.obj.mapReduceFinancial(debits, 'amount')
    };

    // console.log('overview object\n' + JSON.stringify(out, null, 2));
    return out;
}

class SafetyNetStatus {

    constructor(userId) {
        console.log("SafetyNetStatus");

        this.totalBalance = 0;
        this.months = -1;
        this.accountCount = 0;
        this.targetMonths = 6.0;
    }
}

class FlowScore {

    constructor(userId) {
        console.log("FlowScore");

        this.responsibilty = "B";
        this.magnitude = 65;
    }
}
